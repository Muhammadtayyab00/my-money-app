package com.example.mymoney;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class settingsActivity extends AppCompatActivity {

    private TextView timeTextView;
    private ImageView profileIconImageView;
    private TextView guestTextView;
    private TextView generalHeaderTextView;
    private TextView currencyOptionTextView;
    private TextView walletsOptionTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen_2);

        // Initialize views
        timeTextView = findViewById(R.id.time);
        profileIconImageView = findViewById(R.id.profile_icon);
        guestTextView = findViewById(R.id.guest_text);
        generalHeaderTextView = findViewById(R.id.general_header);
        currencyOptionTextView = findViewById(R.id.currency_option);
        walletsOptionTextView = findViewById(R.id.wallets_option);

        // Set initial data for TextViews
        timeTextView.setText("6:32");  // This can be dynamically updated
        guestTextView.setText("Guest");
        generalHeaderTextView.setText("General");
        currencyOptionTextView.setText("Currency");
        walletsOptionTextView.setText("Wallets");

    }
}
