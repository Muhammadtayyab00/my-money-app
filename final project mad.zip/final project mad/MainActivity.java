package com.example.mymoney;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView timeTextView;
    private TextView greetingTextView;
    private TextView totalBalanceTextView;
    private TextView balanceAmountTextView;
    private TextView cashBalanceTextView;
    private TextView cashAmountTextView;
    private ImageView noTransactionsIcon;
    private TextView noTransactionTextView;
    private Button addTransactionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        timeTextView = findViewById(R.id.time);
        greetingTextView = findViewById(R.id.greeting);
        totalBalanceTextView = findViewById(R.id.total_balance);
        balanceAmountTextView = findViewById(R.id.balance_amount);
        cashBalanceTextView = findViewById(R.id.cash_balance);
        cashAmountTextView = findViewById(R.id.cash_amount);
        noTransactionsIcon = findViewById(R.id.no_transactions_icon);
        noTransactionTextView = findViewById(R.id.no_transaction_text);
        addTransactionButton = findViewById(R.id.add_transaction_button);

        // Set initial data for TextViews (can be updated dynamically in your app)
        timeTextView.setText("6:32");
        greetingTextView.setText("Good evening, Guest");
        balanceAmountTextView.setText("$0.00");
        cashAmountTextView.setText("$0.00");

        // Set click listener for the add transaction button
        addTransactionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
                // Code to add a new transaction
            }
        });
    }
}
