package com.example.mymoney;
public class ReportActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TransactionAdapter adapter;
    private List<Transaction> transactionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerViewTransactions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize transaction list
        transactionList = new ArrayList<>();
        transactionList.add(new Transaction("Groceries", 50.00));
        transactionList.add(new Transaction("Salary", 1500.00));

        // Set adapter
        adapter = new TransactionAdapter(transactionList);
        recyclerView.setAdapter(adapter);
        }
}
