package com.example.mymoney;
public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {

    private List<Transaction> transactions;

    public TransactionAdapter(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    @Override
    public TransactionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TransactionViewHolder holder, int position) {
        Transaction transaction = transactions.get(position);
        holder.tvTransactionTitle.setText(transaction.getTitle());
        holder.tvTransactionAmount.setText(String.valueOf(transaction.getAmount()));
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }

    public class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView tvTransactionTitle, tvTransactionAmount;

        public TransactionViewHolder(View itemView) {
            super(itemView);
            tvTransactionTitle = itemView.findViewById(R.id.tvTransactionTitle);
            tvTransactionAmount = itemView.findViewById(R.id.tvTransactionAmount);
 }
}
}

