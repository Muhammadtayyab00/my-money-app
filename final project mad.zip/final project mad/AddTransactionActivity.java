package com.example.mymoney;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddTransactionActivity extends AppCompatActivity {

    private ImageView ivBack, ivCategoryBill;
    private TextView tvTitle, tvExpense, tvIncome, tvDate, tvCategoryBill;
    private Spinner spinnerPaymentMethod;
    private EditText etAmount;
    private Button btnDone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen_4);

        // Initialize Views
        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        tvExpense = findViewById(R.id.tv_expense);
        tvIncome = findViewById(R.id.tv_income);
        tvDate = findViewById(R.id.tv_date);
        spinnerPaymentMethod = findViewById(R.id.spinner_payment_method);
        etAmount = findViewById(R.id.et_amount);
        btnDone = findViewById(R.id.btn_done);
        ivCategoryBill = findViewById(R.id.iv_category_bill);
        tvCategoryBill = findViewById(R.id.tv_category_bill);

        // Back Button Click Listener
        ivBack.setOnClickListener(v -> {
            // Navigate back to the previous screen
            finish();
        });

        // Spinner Item Selected Listener
        spinnerPaymentMethod.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedMethod = parent.getItemAtPosition(position).toString();
                Toast.makeText(AddTransactionActivity.this, "Selected: " + selectedMethod, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Expense/Income Tab Click Listeners
        tvExpense.setOnClickListener(v -> {
            tvExpense.setTextColor(getResources().getColor(R.color.black));
            tvIncome.setTextColor(getResources().getColor(android.R.color.darker_gray));
            Toast.makeText(this, "Expense Selected", Toast.LENGTH_SHORT).show();
        });

        tvIncome.setOnClickListener(v -> {
            tvIncome.setTextColor(getResources().getColor(R.color.black));
            tvExpense.setTextColor(getResources().getColor(android.R.color.darker_gray));
            Toast.makeText(this, "Income Selected", Toast.LENGTH_SHORT).show();
        });

        // Category Click Listener
        ivCategoryBill.setOnClickListener(v -> {
            Toast.makeText(this, "Category: Bill Selected", Toast.LENGTH_SHORT).show();
        });

        // Done Button Click Listener
        btnDone.setOnClickListener(v -> {
            String amount = etAmount.getText().toString().trim();
            if (amount.isEmpty()) {
                Toast.makeText(this, "Please enter an amount", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Transaction Added: " + amount, Toast.LENGTH_SHORT).show();
                // Handle saving the transaction
                finish();
            }
        });
    }
}
