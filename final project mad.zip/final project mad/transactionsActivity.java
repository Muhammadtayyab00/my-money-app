package com.example.mymoney;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.LinearLayout;

public class transactionsActivity extends AppCompatActivity {

    private TextView transactionTitleTextView;
    private TextView transactionItem1TextView;
    private TextView transactionItem2TextView;
    private Button newTransactionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen_3);

        // Initialize views
        transactionTitleTextView = findViewById(R.id.transaction_title);
        transactionItem1TextView = findViewById(R.id.transaction_item1);
        transactionItem2TextView = findViewById(R.id.transaction_item2);
        newTransactionButton = findViewById(R.id.new_transaction_btn);

        // Set initial data for TextViews
        transactionTitleTextView.setText("Transactions");
        transactionItem1TextView.setText("Groceries - $45.00");
        transactionItem2TextView.setText("Dining - $25.00");

        // Set click listener for the Add New Transaction button
        newTransactionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle adding a new transaction
                // Code to launch new transaction activity or dialog
            }
        });
    }
}
